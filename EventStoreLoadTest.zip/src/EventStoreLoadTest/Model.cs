﻿using EventStore.ClientAPI;
using System;
using System.Threading;

namespace EventStoreLoadTestConsumer
{    
    public class Model
    {
        private string _streamName;
        private int EventCount { get; set; }
        public static int Total = 0;
        private static EventWaitHandle _waitHandle;

        private long? _streamPosition = null;

        public Model(string streamName)
        {
            _streamName = streamName;
            CatchUpAndSubscrbeToStream(streamName);
        }

        private void CatchUpAndSubscrbeToStream(string streamName)
        {
            _streamName = streamName;
            _waitHandle = new EventWaitHandle(false, EventResetMode.AutoReset);

            // new CatchUpSubscriptionSettings(1, 500, false, true);            
            Program.Connection.SubscribeToStreamFrom(streamName, _streamPosition, CatchUpSubscriptionSettings.Default,
                EventAppeared, liveProcessingStarted, SubscriptionDropped);
            _waitHandle.WaitOne();
        }

        private void EventAppeared(EventStoreCatchUpSubscription subscription, ResolvedEvent resolvedEvent)
        {
            if (resolvedEvent.OriginalPosition != null)
                _streamPosition = resolvedEvent.OriginalPosition.Value.CommitPosition;

            EventCount++;
            Interlocked.Increment(ref Total);

            //if (Total % 10000 == 0)
                Console.WriteLine($"Event from Stream {resolvedEvent.Event.EventStreamId} processed, Total: {Total}, {DateTime.Now}");
            //Encoding.ASCII.GetString(x.Event.Data)
        }

        private void liveProcessingStarted(EventStoreCatchUpSubscription obj)
        {
            _waitHandle.Set();
        }

        private  void SubscriptionDropped(EventStoreCatchUpSubscription supscription, SubscriptionDropReason dropReason, Exception ex)
        {
            //Console.WriteLine($"Subscription to {supscription.StreamId} dropped! Reason: {dropReason.ToString()}");

            //if (ex != null)
                Console.WriteLine($"SubscriptionDropped, Exception: {ex}");

            void ResubscriptOnConnected(object sender, ClientConnectionEventArgs args)
            {
                CatchUpAndSubscrbeToStream(_streamName);

                Console.WriteLine($"resubscrbeing to {_streamName} from {_streamPosition}");
                Program.Connection.Connected -= ResubscriptOnConnected;
            }
            Program.Connection.Connected += ResubscriptOnConnected;

            _waitHandle.Set();
        }
    }
}
