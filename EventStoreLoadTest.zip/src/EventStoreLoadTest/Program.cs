﻿using EventStore.ClientAPI;
using System;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EventStoreLoadTestConsumer
{
    public class Program
    {
        private const int DefaultPort = 1113;
        private const int TotalStreams = 1; // 4 million
        private const string StreamName = "TEST_STREAM-";
        private static Random _rnd = new Random();
        public static IEventStoreConnection Connection;

        //static List<Model> _models = new List<Model>(TOTAL_STREAMS);

        public static void Main(string[] args)
        {
            Console.Title = "Event Store Load Test: Consumer";
            var settings = ConnectionSettings.Create();
            settings.UseConsoleLogger();
            //settings.KeepReconnecting();
            //settings.KeepRetrying();
            //settings.LimitReconnectionsTo(1);
            //settings.LimitAttemptsForOperationTo(1);
            //settings.LimitRetriesForOperationTo(1);
            //settings.SetOperationTimeoutTo(new TimeSpan(0, 0, 0, 2));

            settings.FailOnNoServerResponse();

            //settings.EnableVerboseLogging();
            using (Connection = EventStoreConnection.Create(settings, new IPEndPoint(IPAddress.Loopback, DefaultPort)))
            {
                //Connection.Connected += (sender, eventArgs) => Console.WriteLine("EventStore connected");
                Connection.ConnectAsync().Wait();
                bool reconnected = false;
                Connection.Connected += (sender, eventArgs) => { reconnected = true; };

                Connection.Closed += (sender, eventArgs) =>
                {
                    reconnected = false;
                    Console.WriteLine("reconnecting");
                    while (!reconnected)
                    {
                        try
                        {
                            Connection = EventStoreConnection.Create(settings,
                                new IPEndPoint(IPAddress.Loopback, DefaultPort));
                            Connection.ConnectAsync().Wait();
                        }
                        catch (Exception)
                        {
                            // ignored
                        }
                    }
                    Console.WriteLine("reconnected");
                };


                Console.WriteLine($"Consumer: Begin Subscribing to using {TotalStreams} streams at: {DateTime.Now}");
                for (int i = 1; i <= TotalStreams; i++)
                //Parallel.For(0, TotalStreams, i =>
                {
                    //_models.Add(new Model(connection, thisStreamName));
                    var unused = new Model(StreamName + i);
                    //Thread.Sleep(20);

                    if (i % 10000 == 0)
                        Console.WriteLine($"Model & Subscription: {i}, Total: {Model.Total} at: {DateTime.Now}");
                }
                //);

                //Thread.Sleep(1 * 60 * 1000);

                //Console.WriteLine($"All Done!, total: { + _models.Sum(x => x.EventCount)} at , {DateTime.Now}");
                Console.WriteLine($"All Done!, total: {Model.Total} at {DateTime.Now}");


                Console.WriteLine("Press x to quit");
                while (Console.ReadLine() != "x")
                {
                    Console.WriteLine($"Total now: {Model.Total}");
                }
            }
        }
    }
}
