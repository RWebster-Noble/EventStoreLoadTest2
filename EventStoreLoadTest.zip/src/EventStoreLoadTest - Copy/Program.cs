﻿using EventStore.ClientAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EventStoreLoadTestProducer
{
    public class Program
    {
        private const int DefaultPort = 1113;
        private const int TotalStreams = 0; // 4 million
        private const int EventsPerStream = 0;
        private const string StreamName = "TEST_STREAM-";
        private static Random rnd = new Random();
        private static IEventStoreConnection _connection;

        //static List<Model> _models = new List<Model>(TOTAL_STREAMS);

        public static void Main(string[] args)
        {
            Console.Title = "Event Store Load Test: Producer";
            var settings = ConnectionSettings.Create();
            //settings.UseConsoleLogger();
            //settings.KeepReconnecting();
            //settings.KeepRetrying();
            //settings.LimitReconnectionsTo(1);
            //settings.LimitAttemptsForOperationTo(1);
            //settings.LimitRetriesForOperationTo(1);
            //settings.SetOperationTimeoutTo(new TimeSpan(0, 0, 0, 2));

            //settings.LimitReconnectionsTo(0);;
            //settings.LimitAttemptsForOperationTo(1);
            //settings.LimitRetriesForOperationTo(1);
            //settings.SetOperationTimeoutTo(TimeSpan.FromSeconds(1));
            //settings.WithConnectionTimeoutOf(TimeSpan.FromSeconds(1));
            //settings.SetReconnectionDelayTo(TimeSpan.FromSeconds(1));
            //settings.LimitOperationsQueueTo(1);


            //settings.EnableVerboseLogging();
            using ( _connection = EventStoreConnection.Create(settings, new IPEndPoint(IPAddress.Loopback, DefaultPort)))
            {
                //_connection.Reconnecting += (sender, eventArgs) => Console.WriteLine("Reconnecting");
                _connection.ConnectAsync().Wait();

                Console.WriteLine($"Producer: Begin Ganerating {TotalStreams} Streams with {EventsPerStream + 1} events in each, totaling {TotalStreams * (EventsPerStream + 1)} events, at {DateTime.Now}");
                for (int i = 1; i <= TotalStreams; i++)
                //Parallel.For(0, TOTAL_STREAMS, i =>
                {
                    RaiseEventFor(i);
                    

                    //for (int j = 0; j < EventsPerStream; j++)
                    //{
                    //    //int randomStream = rnd.Next(Math.Max(streamNumber - 10, 1), streamNumber);
                    //    //int actual = (int)Math.Ceiling((1.0 / ((double)streamNumber)+1) * (double)randomStream);
                    //    int randomStream = i;
                    //    string thisStreamName = StreamName + randomStream;
                    //    connection.AppendToStreamAsync(thisStreamName,
                    //        ExpectedVersion.Any,
                    //        RaiseEventFor(i)).Wait();
                    //}
                    //Thread.Sleep(20);

                    if (i % 10000 == 0)
                        Console.WriteLine($"Events For Stream: {i} at {DateTime.Now}");
                }//);
                Console.WriteLine($"{TotalStreams} Streams with {EventsPerStream + 1} events in each, totaling {TotalStreams*(EventsPerStream + 1)} events. Made at {DateTime.Now}");


                Console.WriteLine("Press x to quit");
                string input;
                do
                {
                    input = Console.ReadLine();
                    switch (input)
                    {
                        case "e":
                            RaiseEventFor(1);
                            Console.WriteLine("Event Made");
                            break;
                    }
                } while (input != "x");
            }
        }

        private static void RaiseEventFor(int i)
        {
            var evt =  new EventData(
                Guid.NewGuid(),
                "eventType",
                true,
                Encoding.ASCII.GetBytes("{\"e\" : " + i + "}"),
                null
                );

            try
            {
                _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt).Wait();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }


            //RaiseEvent(i, evt);


            //var cts = new CancellationTokenSource();
            //var task2 = _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt);
            //Parallel.Invoke(() =>
            //{
            //    task2.Wait(cts.Token);
            //    cts.Cancel();
            //}, () =>
            //{
            //    Task.Delay(new TimeSpan(0,0,5), cts.Token).Wait();
            //    cts.Cancel();
            //    Console.WriteLine("timeout");
            //});

            //var cts = new CancellationTokenSource();

            //var timeoutTask = new Task(() =>
            //{
            //    Console.WriteLine("foo");

            //    Thread.Sleep(5000);
            //    cts.Cancel();
            //    Console.WriteLine("timeout");
            //});

            //var raiseTask = new Task(() =>
            //{
            //    Console.WriteLine("bar");

            //    _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt).Wait(cts.Token);
            //    Console.WriteLine("wrote event");
            //});

            //if (await Task.WhenAny(raiseTask, timeoutTask) == raiseTask)
            //{
            //    Console.WriteLine("complete");
            //}
            //else
            //{
            //    Console.WriteLine("fail");

            //}

            //var task = _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt);
            //if (await Task.WhenAny(task, Task.Delay(5000)) == task)
            //{
            //    Console.WriteLine("complete");
            //}
            //else
            //{
            //    Console.WriteLine("fail");

            //}

            //var cancellationToken = new CancellationTokenSource();
            //cancellationToken.CancelAfter(1000);

            //try
            //{
            //    _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt).Wait(cancellationToken.Token);
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e);
            //}

            //if (cancellationToken.Token.IsCancellationRequested)
            //    Console.WriteLine("Timeout");

            //try
            //{
            //    var cts = new CancellationTokenSource();
            //    var task2 = _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt);
            //    Parallel.Invoke(() =>
            //    {
            //        task2.Wait(cts.Token);
            //        //cts.Cancel();
            //    }, () =>
            //    {
            //        //new Task(() => { Task.Delay(new TimeSpan(0, 0, 1), cts.Token); }).Wait();
            //        Thread.Sleep(1000);
            //        cts.Cancel();
            //        Console.WriteLine("timeout");
            //    });
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e);
            //}

            //_connection.AppendToStreamAsync(StreamName + i,
            //    ExpectedVersion.Any, evt).Wait();
        }

        private static void RaiseEvent(int i, EventData evt)
        {
            var cts = new CancellationTokenSource();
            Task task = new Task(() =>
            {
                _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt).Wait(cts.Token);
                cts.Cancel();
            });


           // var task = _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt);

            
            if (Task.WhenAny(task, Task.Delay(5000, cts.Token)) == task)
            {
                // Task completed within timeout.
                // Consider that the task may have faulted or been canceled.
                // We re-await the task so that any exceptions/cancellation is rethrown.
                cts.Cancel();
            }
            else
            {
                // timeout/cancellation logic
            }




            //var cts = new CancellationTokenSource();
            //var task =
            //    _connection.AppendToStreamAsync(StreamName + i, ExpectedVersion.Any, evt);

            //delegate d () =>
            //{
            //    task.Wait(cts.Token);
            //    cts.Cancel();
            //}

            //var t2 = new Task(() =>
            //{
            //    Task.Delay(new TimeSpan(0,0,5), cts.Token).Start();
            //    cts.Cancel();
            //});

            //Parallel.Invoke(() => t.Wait(), () => t2.Wait());

            //if (await Task.WhenAny(t, t2) == task)
            //{
            //    Console.WriteLine("complete");
            //}
            //else
            //{
            //    Console.WriteLine("fail");
            //}
        }
    }


    
}
